import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Kitiki Masemola\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://demo.guru99.com/test/newtours/login.php");
		
		driver.findElement(By.name("userName")).sendKeys("kitiki203@gmail.com");
		driver.findElement(By.name("password")).sendKeys("Masemola98");
		driver.findElement(By.name("submit")).click();
		
		
		String actualURL= "http://demo.guru99.com/test/newtours/login_sucess.php";
		String expectedURL= driver.getCurrentUrl();
		
		 if(actualURL.equals(expectedURL)) {
			 System.out.println("Test Passed");
		 }else {
			 System.out.println("Test Failed");
		 }
		driver.close();
	}

}
