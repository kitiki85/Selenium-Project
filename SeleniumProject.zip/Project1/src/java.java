import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import java.util.concurrent.TimeUnit;

public class java {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Kitiki Masemola\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("http://demo.guru99.com/test/newtours/");
		String actualTitle = driver.getTitle();
		driver.manage().window().maximize();
		String expectedTitle= "Mercury tours";
		
	if(actualTitle.equals(expectedTitle)) {
		
		System.out.println("Test Passed");
	}else {
		System.out.println("Test Failed");
	}
	driver.close();
 }

}
