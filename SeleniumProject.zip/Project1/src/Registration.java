import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class Registration {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Kitiki Masemola\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://demo.guru99.com/test/newtours/register.php");
		
		String actualURL= "http://demo.guru99.com/test/newtours/register_sucess.php";
		String expectedURL= driver.getCurrentUrl();
		driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table/tbody/tr/td[2]/a")).click();
		driver.findElement(By.name("firstName")).sendKeys("Seipelo");
		driver.findElement(By.name("lastName")).sendKeys("Masemola");
		driver.findElement(By.name("phone")).sendKeys("0658584113");
		driver.findElement(By.name("userName")).sendKeys("kitiki203@gmail.com");
		driver.findElement(By.name("Address")).sendKeys("59 woodlands Avenue");
		driver.findElement(By.name("City")).sendKeys("Sandton");
		driver.findElement(By.name("state")).sendKeys("Gauteng");
		Select country= new Select(driver.findElement(By.name("country")));
		country.selectByVisibleText("SOUTH AFRICA");
		
	    driver.findElement(By.name("postalCode")).sendKeys("9194");
		driver.findElement(By.name("country")).sendKeys("kitiki203@gmail.com");
		driver.findElement(By.name("password")).sendKeys("Masemola98");
		driver.findElement(By.name("confirmPassword")).sendKeys("Masemola98");
		
		driver.findElement(By.name("submit")).click();
		
		 if(actualURL.equals(expectedURL)) {
			 System.out.println("Test Passed");
		 }else {
			 System.out.println("Test Failed");
		 }
		
 }

}
